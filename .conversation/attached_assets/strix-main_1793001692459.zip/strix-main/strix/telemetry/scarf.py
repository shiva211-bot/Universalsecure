from __future__ import annotations

import json
import logging
import urllib.parse
from typing import TYPE_CHECKING, Any

import requests

from strix.config import load_settings
from strix.skills import get_loaded_skill_names
from strix.telemetry._common import (
    SEND_TIMEOUT,
    SESSION_ID,
    base_props,
    exception_props,
    get_scan_phase,
    get_version,
    is_first_run,
)


if TYPE_CHECKING:
    from strix.report.state import ReportState


logger = logging.getLogger(__name__)

_SCARF_ENDPOINT = "https://strix.gateway.scarf.sh"


def _is_enabled() -> bool:
    return load_settings().telemetry.enabled


def _send(event: str, properties: dict[str, Any]) -> bool:
    if not _is_enabled():
        logger.debug("scarf disabled; skipping event %s", event)
        return False
    try:
        props = dict(properties)
        version = str(props.pop("strix_version", get_version()) or "unknown")
        path = f"/{urllib.parse.quote(event, safe='')}/{urllib.parse.quote(version, safe='')}"
        query = urllib.parse.urlencode(
            {k: ("" if v is None else str(v)) for k, v in props.items()},
        )
        url = f"{_SCARF_ENDPOINT}{path}"
        if query:
            url = f"{url}?{query}"
        with requests.post(url, timeout=SEND_TIMEOUT):
            pass
    except Exception:  # noqa: BLE001
        logger.debug("scarf send failed for event %s", event, exc_info=True)
        return False
    else:
        logger.debug("scarf event sent: %s", event)
        return True


def start(
    model: str | None,
    scan_mode: str | None,
    is_whitebox: bool,
    interactive: bool,
    has_instructions: bool,
    auth_mode: str | None = None,
) -> None:
    _send(
        "scan_started",
        {
            **base_props(),
            "session": SESSION_ID,
            "model": model or "unknown",
            "auth_mode": auth_mode or "api_key",
            "scan_mode": scan_mode or "unknown",
            "scan_type": "whitebox" if is_whitebox else "blackbox",
            "interactive": interactive,
            "has_instructions": has_instructions,
            "first_run": is_first_run(),
        },
    )


def finding(severity: str, cwe: str | None = None, is_cve: bool = False) -> None:
    _send(
        "finding_reported",
        {
            **base_props(),
            "session": SESSION_ID,
            "severity": severity.lower(),
            "cwe": (cwe or "").strip().lower() or "unknown",
            "is_cve": is_cve,
        },
    )


def end(report_state: ReportState, exit_reason: str = "completed") -> None:
    if report_state.scarf_scan_ended_sent:
        return
    if report_state.scan_ended_exit_reason is None:
        report_state.scan_ended_exit_reason = exit_reason

    vulnerabilities_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
    for v in report_state.vulnerability_reports:
        sev = v.get("severity", "info").lower()
        if sev in vulnerabilities_counts:
            vulnerabilities_counts[sev] += 1

    duration = report_state.get_process_duration_seconds()

    llm_props: dict[str, int | float] = {}
    try:
        usage = report_state.get_process_llm_usage()
        if isinstance(usage, dict):
            llm_props = {
                "llm_requests": int(usage.get("requests") or 0),
                "llm_input_tokens": int(usage.get("input_tokens") or 0),
                "llm_output_tokens": int(usage.get("output_tokens") or 0),
                "llm_tokens": int(usage.get("total_tokens") or 0),
                "llm_cost": float(usage.get("cost") or 0.0),
            }
    except (TypeError, ValueError, AttributeError):
        pass
    providers = report_state.get_process_llm_providers()

    report_state.scarf_scan_ended_sent = _send(
        "scan_ended",
        {
            **base_props(),
            "session": SESSION_ID,
            "auth_mode": report_state.run_record.get("auth_mode") or "api_key",
            "exit_reason": report_state.scan_ended_exit_reason,
            "duration_seconds": round(duration),
            "vulnerabilities_total": len(report_state.vulnerability_reports),
            **{f"vulnerabilities_{k}": v for k, v in vulnerabilities_counts.items()},
            **llm_props,
            # Query params are flat, so the per-provider tally travels as JSON.
            **({"llm_providers": json.dumps(providers)} if providers else {}),
            "skills": ",".join(get_loaded_skill_names()),
        },
    )


def error(error_type: str, exc: BaseException | None = None) -> None:
    props: dict[str, Any] = {
        **base_props(),
        "session": SESSION_ID,
        "error_type": error_type,
        "phase": get_scan_phase(),
    }
    if exc is not None:
        props.update(exception_props(exc))
    _send("error", props)
